//
/*
 *
 *Class required by Geant
 *simply dictates what kind of file to 
 *store data in.
 *CVS is also an option
 *
 */

#ifndef Analysis_h
#define Analysis_h 1

#include "g4root.hh"
//#include "g4xml.hh"

#endif
